package com.nova.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nova.app.data.model.AuthResponse
import com.nova.app.data.remote.ApiClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AuthUiState(
    val isLoading: Boolean = false,
    val isAuthenticated: Boolean = false,
    val error: String? = null
)

class AuthViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    fun login(username: String, password: String) {
        _uiState.value = AuthUiState(isLoading = true)
        viewModelScope.launch {
            val result = ApiClient.login(username, password)
            result.onSuccess {
                _uiState.value = AuthUiState(isAuthenticated = true)
            }.onFailure { e ->
                _uiState.value = AuthUiState(error = e.message ?: "Login failed")
            }
        }
    }

    fun register(username: String, password: String, displayName: String) {
        _uiState.value = AuthUiState(isLoading = true)
        viewModelScope.launch {
            val result = ApiClient.register(username, password, displayName)
            result.onSuccess {
                _uiState.value = AuthUiState(isAuthenticated = true)
            }.onFailure { e ->
                _uiState.value = AuthUiState(error = e.message ?: "Registration failed")
            }
        }
    }

    fun reset() {
        _uiState.value = AuthUiState()
    }
}
