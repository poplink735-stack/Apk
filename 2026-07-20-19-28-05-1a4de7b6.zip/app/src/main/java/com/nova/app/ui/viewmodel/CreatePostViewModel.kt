package com.nova.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nova.app.data.model.Post
import com.nova.app.data.remote.ApiClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class CreatePostUiState(
    val isPosting: Boolean = false,
    val isSuccess: Boolean = false,
    val error: String? = null
)

class CreatePostViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(CreatePostUiState())
    val uiState: StateFlow<CreatePostUiState> = _uiState.asStateFlow()

    fun createPost(content: String, imageBase64: String? = null) {
        if (content.isBlank()) return
        _uiState.value = CreatePostUiState(isPosting = true)
        viewModelScope.launch {
            val result = ApiClient.createPost(content, imageBase64)
            result.onSuccess {
                _uiState.value = CreatePostUiState(isSuccess = true)
            }.onFailure { e ->
                _uiState.value = CreatePostUiState(error = e.message ?: "Failed to post")
            }
        }
    }

    fun reset() {
        _uiState.value = CreatePostUiState()
    }
}
