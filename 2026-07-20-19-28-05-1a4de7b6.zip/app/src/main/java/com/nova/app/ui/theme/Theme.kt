package com.nova.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NovaColorScheme = lightColorScheme(
    primary = NovaAccent,
    onPrimary = NovaWhite,
    primaryContainer = NovaAccent.copy(alpha = 0.12f),
    onPrimaryContainer = NovaAccent,
    secondary = NovaDark,
    onSecondary = NovaWhite,
    background = NovaLight,
    onBackground = NovaDark,
    surface = NovaCard,
    onSurface = NovaDark,
    surfaceVariant = NovaLightGray,
    onSurfaceVariant = NovaGray,
    outline = NovaLightGray,
    error = NovaRed,
    onError = NovaWhite,
)

@Composable
fun NovaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = NovaColorScheme,
        content = content
    )
}
