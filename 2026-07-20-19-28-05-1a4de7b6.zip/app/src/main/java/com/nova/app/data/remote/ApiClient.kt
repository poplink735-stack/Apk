package com.nova.app.data.remote

import com.nova.app.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * Ultra-lightweight API client using built-in HttpURLConnection.
 * No Retrofit, no OkHttp — saves ~500KB+ in APK size.
 */
object ApiClient {

    // Change this to your actual API base URL
    private const val BASE_URL = "https://api.nova.social/v1"
    private const val TIMEOUT_MS = 15000

    private var authToken: String? = null

    fun setToken(token: String) {
        authToken = token
    }

    fun clearToken() {
        authToken = null
    }

    suspend fun login(username: String, password: String): Result<AuthResponse> =
        withContext(Dispatchers.IO) {
            try {
                val json = JSONObject().apply {
                    put("username", username)
                    put("password", password)
                }
                val response = post("$BASE_URL/auth/login", json)
                val auth = AuthResponse(
                    token = response.getString("token"),
                    userId = response.getString("userId"),
                    username = response.getString("username"),
                    displayName = response.optString("displayName", username)
                )
                authToken = auth.token
                Result.success(auth)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun register(username: String, password: String, displayName: String): Result<AuthResponse> =
        withContext(Dispatchers.IO) {
            try {
                val json = JSONObject().apply {
                    put("username", username)
                    put("password", password)
                    put("displayName", displayName)
                }
                val response = post("$BASE_URL/auth/register", json)
                val auth = AuthResponse(
                    token = response.getString("token"),
                    userId = response.getString("userId"),
                    username = response.getString("username"),
                    displayName = response.optString("displayName", displayName)
                )
                authToken = auth.token
                Result.success(auth)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun getFeed(cursor: String? = null): Result<FeedResponse> =
        withContext(Dispatchers.IO) {
            try {
                val url = if (cursor != null) {
                    "$BASE_URL/feed?cursor=$cursor"
                } else {
                    "$BASE_URL/feed"
                }
                val response = get(url)
                val postsArray = response.getJSONArray("posts")
                val posts = mutableListOf<Post>()
                for (i in 0 until postsArray.length()) {
                    posts.add(parsePost(postsArray.getJSONObject(i)))
                }
                Result.success(
                    FeedResponse(
                        posts = posts,
                        hasMore = response.optBoolean("hasMore", false),
                        cursor = response.optString("cursor", null)
                    )
                )
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun createPost(content: String, imageBase64: String? = null): Result<Post> =
        withContext(Dispatchers.IO) {
            try {
                val json = JSONObject().apply {
                    put("content", content)
                    imageBase64?.let { put("image", it) }
                }
                val response = post("$BASE_URL/posts", json)
                Result.success(parsePost(response))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun likePost(postId: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                post("$BASE_URL/posts/$postId/like", JSONObject())
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun unlikePost(postId: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                delete("$BASE_URL/posts/$postId/like")
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun getComments(postId: String): Result<List<Comment>> =
        withContext(Dispatchers.IO) {
            try {
                val response = get("$BASE_URL/posts/$postId/comments")
                val array = response.getJSONArray("comments")
                val comments = mutableListOf<Comment>()
                for (i in 0 until array.length()) {
                    comments.add(parseComment(array.getJSONObject(i)))
                }
                Result.success(comments)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun addComment(postId: String, content: String): Result<Comment> =
        withContext(Dispatchers.IO) {
            try {
                val json = JSONObject().apply { put("content", content) }
                val response = post("$BASE_URL/posts/$postId/comments", json)
                Result.success(parseComment(response))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun getUserProfile(userId: String): Result<User> =
        withContext(Dispatchers.IO) {
            try {
                val response = get("$BASE_URL/users/$userId")
                Result.success(parseUser(response))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    // --- HTTP helpers ---

    private fun post(urlString: String, body: JSONObject): JSONObject {
        val url = URL(urlString)
        val conn = url.openConnection() as HttpURLConnection
        conn.apply {
            requestMethod = "POST"
            connectTimeout = TIMEOUT_MS
            readTimeout = TIMEOUT_MS
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            authToken?.let { setRequestProperty("Authorization", "Bearer $it") }
        }
        return conn.use { c ->
            OutputStreamWriter(c.outputStream).use { writer ->
                writer.write(body.toString())
                writer.flush()
            }
            readResponse(c)
        }
    }

    private fun get(urlString: String): JSONObject {
        val url = URL(urlString)
        val conn = url.openConnection() as HttpURLConnection
        conn.apply {
            requestMethod = "GET"
            connectTimeout = TIMEOUT_MS
            readTimeout = TIMEOUT_MS
            authToken?.let { setRequestProperty("Authorization", "Bearer $it") }
        }
        return conn.use { readResponse(it) }
    }

    private fun delete(urlString: String): JSONObject {
        val url = URL(urlString)
        val conn = url.openConnection() as HttpURLConnection
        conn.apply {
            requestMethod = "DELETE"
            connectTimeout = TIMEOUT_MS
            readTimeout = TIMEOUT_MS
            authToken?.let { setRequestProperty("Authorization", "Bearer $it") }
        }
        return conn.use { readResponse(it) }
    }

    private fun readResponse(conn: HttpURLConnection): JSONObject {
        val stream = if (conn.responseCode in 200..299) {
            conn.inputStream
        } else {
            conn.errorStream
        }
        val reader = BufferedReader(InputStreamReader(stream))
        val response = reader.readText()
        return JSONObject(response)
    }

    // --- Parsers ---

    private fun parsePost(json: JSONObject): Post = Post(
        id = json.getString("id"),
        userId = json.getString("userId"),
        username = json.optString("username", ""),
        displayName = json.optString("displayName", ""),
        avatarUrl = json.optString("avatarUrl", ""),
        content = json.optString("content", ""),
        imageUrl = json.optString("imageUrl", null),
        likeCount = json.optInt("likeCount", 0),
        commentCount = json.optInt("commentCount", 0),
        isLiked = json.optBoolean("isLiked", false),
        timestamp = json.optLong("timestamp", System.currentTimeMillis())
    )

    private fun parseComment(json: JSONObject): Comment = Comment(
        id = json.getString("id"),
        postId = json.optString("postId", ""),
        userId = json.optString("userId", ""),
        username = json.optString("username", ""),
        displayName = json.optString("displayName", ""),
        avatarUrl = json.optString("avatarUrl", ""),
        content = json.optString("content", ""),
        timestamp = json.optLong("timestamp", System.currentTimeMillis())
    )

    private fun parseUser(json: JSONObject): User = User(
        id = json.getString("id"),
        username = json.optString("username", ""),
        displayName = json.optString("displayName", ""),
        avatarUrl = json.optString("avatarUrl", ""),
        bio = json.optString("bio", ""),
        followerCount = json.optInt("followerCount", 0),
        followingCount = json.optInt("followingCount", 0),
        postCount = json.optInt("postCount", 0)
    )
}
