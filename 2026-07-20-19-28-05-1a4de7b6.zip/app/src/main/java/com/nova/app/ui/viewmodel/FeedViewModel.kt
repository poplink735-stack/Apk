package com.nova.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nova.app.data.model.FeedResponse
import com.nova.app.data.model.Post
import com.nova.app.data.remote.ApiClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class FeedUiState(
    val posts: List<Post> = emptyList(),
    val isLoading: Boolean = false,
    val isLoadingMore: Boolean = false,
    val hasMore: Boolean = true,
    val error: String? = null
)

class FeedViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(FeedUiState())
    val uiState: StateFlow<FeedUiState> = _uiState.asStateFlow()

    private var cursor: String? = null

    init {
        loadFeed()
    }

    fun loadFeed() {
        if (_uiState.value.isLoading) return
        _uiState.value = _uiState.value.copy(isLoading = true, error = null)
        viewModelScope.launch {
            val result = ApiClient.getFeed()
            result.onSuccess { response ->
                _uiState.value = _uiState.value.copy(
                    posts = response.posts,
                    isLoading = false,
                    hasMore = response.hasMore
                )
                cursor = response.cursor
            }.onFailure { e ->
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = e.message ?: "Failed to load feed"
                )
            }
        }
    }

    fun loadMore() {
        if (_uiState.value.isLoadingMore || !_uiState.value.hasMore) return
        _uiState.value = _uiState.value.copy(isLoadingMore = true)
        viewModelScope.launch {
            val result = ApiClient.getFeed(cursor)
            result.onSuccess { response ->
                _uiState.value = _uiState.value.copy(
                    posts = _uiState.value.posts + response.posts,
                    isLoadingMore = false,
                    hasMore = response.hasMore
                )
                cursor = response.cursor
            }.onFailure {
                _uiState.value = _uiState.value.copy(isLoadingMore = false)
            }
        }
    }

    fun toggleLike(postId: String) {
        viewModelScope.launch {
            val currentPosts = _uiState.value.posts.toMutableList()
            val index = currentPosts.indexOfFirst { it.id == postId }
            if (index == -1) return@launch

            val post = currentPosts[index]
            val wasLiked = post.isLiked

            // Optimistic update
            currentPosts[index] = post.copy(
                isLiked = !wasLiked,
                likeCount = if (wasLiked) post.likeCount - 1 else post.likeCount + 1
            )
            _uiState.value = _uiState.value.copy(posts = currentPosts)

            // Server call
            val result = if (wasLiked) {
                ApiClient.unlikePost(postId)
            } else {
                ApiClient.likePost(postId)
            }
            result.onFailure {
                // Revert on failure
                currentPosts[index] = post
                _uiState.value = _uiState.value.copy(posts = currentPosts)
            }
        }
    }

    fun refresh() {
        cursor = null
        loadFeed()
    }
}
