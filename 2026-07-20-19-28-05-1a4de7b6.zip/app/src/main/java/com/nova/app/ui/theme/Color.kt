package com.nova.app.ui.theme

import androidx.compose.ui.graphics.Color

// Nova Brand Colors — dark, modern, social media vibe
val NovaDark = Color(0xFF1A1A2E)
val NovaAccent = Color(0xFFE94560)
val NovaSurface = Color(0xFF16213E)
val NovaBackground = Color(0xFF0F3460)
val NovaLight = Color(0xFFF5F5FA)
val NovaGray = Color(0xFF8E8E93)
val NovaLightGray = Color(0xFFE5E5EA)
val NovaWhite = Color(0xFFFFFFFF)
val NovaCard = Color(0xFFFFFFFF)
val NovaRed = Color(0xFFFF3B30)
val NovaGreen = Color(0xFF34C759)
val NovaBlue = Color(0xFF007AFF)
