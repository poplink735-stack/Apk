package com.nova.app.data.model

data class User(
    val id: String = "",
    val username: String = "",
    val displayName: String = "",
    val avatarUrl: String = "",
    val bio: String = "",
    val followerCount: Int = 0,
    val followingCount: Int = 0,
    val postCount: Int = 0
)

data class Post(
    val id: String = "",
    val userId: String = "",
    val username: String = "",
    val displayName: String = "",
    val avatarUrl: String = "",
    val content: String = "",
    val imageUrl: String? = null,
    val likeCount: Int = 0,
    val commentCount: Int = 0,
    val isLiked: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

data class Comment(
    val id: String = "",
    val postId: String = "",
    val userId: String = "",
    val username: String = "",
    val displayName: String = "",
    val avatarUrl: String = "",
    val content: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

data class AuthResponse(
    val token: String = "",
    val userId: String = "",
    val username: String = "",
    val displayName: String = ""
)

data class FeedResponse(
    val posts: List<Post> = emptyList(),
    val hasMore: Boolean = false,
    val cursor: String? = null
)
