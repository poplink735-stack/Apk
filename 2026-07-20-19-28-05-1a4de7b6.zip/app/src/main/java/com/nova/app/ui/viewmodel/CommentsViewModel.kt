package com.nova.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nova.app.data.model.Comment
import com.nova.app.data.remote.ApiClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class CommentsUiState(
    val comments: List<Comment> = emptyList(),
    val isLoading: Boolean = false,
    val isPosting: Boolean = false,
    val error: String? = null
)

class CommentsViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(CommentsUiState())
    val uiState: StateFlow<CommentsUiState> = _uiState.asStateFlow()

    private var postId: String = ""

    fun loadComments(postId: String) {
        this.postId = postId
        _uiState.value = _uiState.value.copy(isLoading = true, error = null)
        viewModelScope.launch {
            val result = ApiClient.getComments(postId)
            result.onSuccess { comments ->
                _uiState.value = _uiState.value.copy(
                    comments = comments,
                    isLoading = false
                )
            }.onFailure { e ->
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = e.message ?: "Failed to load comments"
                )
            }
        }
    }

    fun addComment(content: String) {
        if (content.isBlank()) return
        _uiState.value = _uiState.value.copy(isPosting = true)
        viewModelScope.launch {
            val result = ApiClient.addComment(postId, content)
            result.onSuccess { comment ->
                _uiState.value = _uiState.value.copy(
                    comments = _uiState.value.comments + comment,
                    isPosting = false
                )
            }.onFailure {
                _uiState.value = _uiState.value.copy(isPosting = false)
            }
        }
    }
}
