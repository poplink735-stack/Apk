package com.nova.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.nova.app.data.local.SessionManager
import com.nova.app.data.remote.ApiClient
import com.nova.app.ui.screen.CreatePostScreen
import com.nova.app.ui.screen.FeedScreen
import com.nova.app.ui.screen.LoginScreen
import com.nova.app.ui.screen.ProfileScreen
import com.nova.app.ui.theme.NovaAccent

sealed class Screen(val route: String, val title: String) {
    data object Login : Screen("login", "Login")
    data object Feed : Screen("feed", "Feed")
    data object CreatePost : Screen("create_post", "New Post")
    data object Profile : Screen("profile", "Profile")
    data object Comments : Screen("comments/{postId}", "Comments") {
        fun createRoute(postId: String) = "comments/$postId"
    }
}

data class BottomNavItem(
    val screen: Screen,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

private val bottomNavItems = listOf(
    BottomNavItem(Screen.Feed, Icons.Filled.Home, Icons.Outlined.Home),
    BottomNavItem(Screen.CreatePost, Icons.Filled.Add, Icons.Outlined.Add),
    BottomNavItem(Screen.Profile, Icons.Filled.Person, Icons.Outlined.Person)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NovaApp() {
    val context = LocalContext.current
    val session = remember { SessionManager(context) }

    // Check auth state on startup
    var isAuthenticated by remember {
        mutableStateOf<Boolean?>(null)
    }

    LaunchedEffect(Unit) {
        if (session.isLoggedIn) {
            ApiClient.setToken(session.token!!)
            isAuthenticated = true
        } else {
            isAuthenticated = false
        }
    }

    // Show loading while checking auth
    if (isAuthenticated == null) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = NovaAccent)
        }
        return
    }

    if (!isAuthenticated) {
        LoginScreen(
            onAuthenticated = {
                // After login, restore session and set API token
                if (session.isLoggedIn) {
                    session.token?.let { ApiClient.setToken(it) }
                }
                isAuthenticated = true
            }
        )
        return
    }

    // Main app (authenticated)
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    val showBottomBar = currentDestination?.route in listOf(
        Screen.Feed.route,
        Screen.CreatePost.route,
        Screen.Profile.route
    )

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = NavigationBarDefaults.Elevation
                ) {
                    bottomNavItems.forEach { item ->
                        val selected = currentDestination?.hierarchy?.any {
                            it.route == item.screen.route
                        } == true
                        NavigationBarItem(
                            icon = {
                                Icon(
                                    imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                    contentDescription = item.screen.title
                                )
                            },
                            label = { Text(item.screen.title) },
                            selected = selected,
                            onClick = {
                                navController.navigate(item.screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Feed.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Feed.route) {
                FeedScreen(
                    onPostClick = { postId ->
                        navController.navigate(Screen.Comments.createRoute(postId))
                    }
                )
            }
            composable(Screen.CreatePost.route) {
                CreatePostScreen()
            }
            composable(Screen.Profile.route) {
                ProfileScreen()
            }
            composable(Screen.Comments.route) { backStackEntry ->
                val postId = backStackEntry.arguments?.getString("postId") ?: ""
                com.nova.app.ui.screen.CommentsScreen(
                    postId = postId,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
