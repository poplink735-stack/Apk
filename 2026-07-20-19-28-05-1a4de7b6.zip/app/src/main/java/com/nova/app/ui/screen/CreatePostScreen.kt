package com.nova.app.ui.screen

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.nova.app.ui.theme.*
import com.nova.app.ui.viewmodel.CreatePostViewModel
import java.io.ByteArrayOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreatePostScreen(
    viewModel: CreatePostViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    var content by remember { mutableStateOf("") }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }

    val context = LocalContext.current
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        selectedImageUri = uri
    }

    LaunchedEffect(uiState.isSuccess) {
        if (uiState.isSuccess) {
            content = ""
            selectedImageUri = null
            viewModel.reset()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "New Post",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = NovaDark
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Text input
        OutlinedTextField(
            value = content,
            onValueChange = { content = it },
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 150.dp),
            placeholder = { Text("What's on your mind?") },
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NovaAccent,
                unfocusedBorderColor = NovaLightGray
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Image picker button
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilledTonalButton(
                onClick = { imagePickerLauncher.launch("image/*") },
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = NovaAccent.copy(alpha = 0.1f)
                )
            ) {
                Text("📷 Add Image", color = NovaAccent)
            }

            if (selectedImageUri != null) {
                Spacer(modifier = Modifier.width(8.dp))
                TextButton(onClick = { selectedImageUri = null }) {
                    Text("Remove", color = NovaRed, fontSize = 13.sp)
                }
            }
        }

        // Image preview
        if (selectedImageUri != null) {
            Spacer(modifier = Modifier.height(8.dp))
            AsyncImage(
                model = selectedImageUri,
                contentDescription = "Selected image",
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 250.dp)
                    .clip(RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Crop
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Post button
        Button(
            onClick = {
                // Convert image URI to base64 for API
                val base64 = selectedImageUri?.let { uri ->
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        val baos = ByteArrayOutputStream()
                        input.copyTo(baos)
                        android.util.Base64.encodeToString(baos.toByteArray(), android.util.Base64.NO_WRAP)
                    }
                }
                viewModel.createPost(content, base64)
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            enabled = content.isNotBlank() && !uiState.isPosting,
            colors = ButtonDefaults.buttonColors(
                containerColor = NovaAccent
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            if (uiState.isPosting) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    strokeWidth = 2.dp,
                    color = NovaWhite
                )
            } else {
                Text("Post", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        // Success message
        if (uiState.isSuccess) {
            Spacer(modifier = Modifier.height(12.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = NovaGreen.copy(alpha = 0.1f))
            ) {
                Text(
                    text = "✅ Posted successfully!",
                    modifier = Modifier.padding(12.dp),
                    color = NovaGreen,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Error message
        if (uiState.error != null) {
            Spacer(modifier = Modifier.height(12.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = NovaRed.copy(alpha = 0.1f))
            ) {
                Text(
                    text = "❌ ${uiState.error}",
                    modifier = Modifier.padding(12.dp),
                    color = NovaRed,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
