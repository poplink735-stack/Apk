# Nova ProGuard Rules
# Keep Compose
-keep class androidx.compose.** { *; }

# Keep Kotlin coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}

# Keep model classes used for JSON serialization
-keep class com.nova.app.data.model.** { *; }

# Keep R8 from stripping Compose animations
-keepclassmembers class * {
    @androidx.compose.runtime.Composable <methods>;
}

# Optimize aggressively
-optimizationpasses 5
-allowaccessmodification
-overloadaggressively
-repackageclasses 'n'
-mergeinterfacesaggressively
